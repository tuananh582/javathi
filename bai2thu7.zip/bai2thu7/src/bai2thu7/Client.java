/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai2thu7;
import java.io.*;
import java.net.*;
import java.util.Scanner;
/**
 *
 * @author admin
 */
public class Client {
    public static void main(String[] args) {
          try (Socket socket = new Socket("localhost", 12345);
             DataOutputStream output = new DataOutputStream(socket.getOutputStream());
             DataInputStream input = new DataInputStream(socket.getInputStream());
             Scanner scanner = new Scanner(System.in)) {

            // Input data
            System.out.print("Nhap Nam Sinh Cua Ban ");
            int birthYear = scanner.nextInt();

            System.out.print("Nhap So Tin Chi ");
            int credits = scanner.nextInt();

            System.out.print("Nhap Don Gia Cua TIn Chi ");
            double creditFee = scanner.nextDouble();

            // Send data to Server
            output.writeInt(birthYear);
            output.writeInt(credits);
            output.writeDouble(creditFee);

            // Receive results from Server
            int age = input.readInt();
            double tuitionFee = input.readDouble();

            System.out.println("Tuoi Cua Ban La: " + age);
            System.out.println("Tien Hoc Phi La : " + tuitionFee);
        } catch (IOException e) {
            System.out.println("Client error: " + e.getMessage());
        }
    }
}
