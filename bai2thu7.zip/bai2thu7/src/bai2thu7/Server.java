/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai2thu7;
import java.io.*;
import java.net.*;
import java.time.Year;
/**
 *
 * @author admin
 */
public class Server {
        public static void main(String[] args) {
         try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("Server is running and waiting for a connection...");

            while (true) {
                try (Socket clientSocket = serverSocket.accept();
                     DataInputStream input = new DataInputStream(clientSocket.getInputStream());
                     DataOutputStream output = new DataOutputStream(clientSocket.getOutputStream())) {

                    System.out.println("Client connected.");

                    // Receive data from Client
                    int birthYear = input.readInt();
                    int tinchi = input.readInt();
                    double dongia = input.readDouble();

                    // Calculate age and tuition fee
                    int currentYear = Year.now().getValue();
                    int age = currentYear - birthYear;
                    double tongtien = tinchi * dongia;

                    // Send results back to Client
                    output.writeInt(age);
                    output.writeDouble(tongtien);

                    System.out.println("Data sent to client: Age = " + age + ", Tuition Fee = " + tongtien);
                } catch (IOException e) {
                    System.out.println("Error processing client request: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("Server error: " + e.getMessage());
        }
            
    }
}
