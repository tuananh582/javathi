/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai1;
import java.util.Scanner;
/**
 *
 * @author admin
 */
public class StringConverter {
     public static String convertString(String input) {
        // Bước 1: Chuẩn hóa khoảng trắng
        String normalized = input.trim().replaceAll("\\s+", " ");

        // Bước 2: Chuyển đổi thành chữ hoa
        String upperCase = normalized.toUpperCase();

        return upperCase;
    }

    public static void main(String[] args) {
        // Sử dụng Scanner để lấy chuỗi đầu vào từ người dùng
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhap Chuoi Can Chuyen Doi:");
        String input = scanner.nextLine();

        // Chuyển đổi và in ra kết quả
        String result = convertString(input);
        System.out.println("Chuoi Da Chuyen Doi " + result);

        scanner.close();
    }
}
