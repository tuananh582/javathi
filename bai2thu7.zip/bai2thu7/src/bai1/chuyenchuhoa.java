/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai1;
import java.util.Scanner;
/**
 *
 * @author admin
 */
public class chuyenchuhoa {
    public static String chuyenchuhoa(String input){
         return input.toUpperCase();
    }
     public static void main(String[] args) {
        // Sử dụng Scanner để lấy chuỗi đầu vào từ người dùng
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhap Chuoi Chuyen Doi Thanh Chu Hoa : ");
        String input = scanner.nextLine();

        // Chuyển đổi và in ra kết quả
        String result = chuyenchuhoa(input);
        System.out.println("Chuoi Da Chuyen Thanh Chu Hoa " + result);

        scanner.close();
    }
}
